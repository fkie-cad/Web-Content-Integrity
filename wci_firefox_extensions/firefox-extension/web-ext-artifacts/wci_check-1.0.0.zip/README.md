# WCI Check Firefox Web-Extension

## Build the Extension

To use the extension and to perform the performance testing, the extension must be built.
This is done by running the following commands:

```sh
npm install
npm run build
```

## Add Extension to Firefox

[Temporary installation in Firefox](https://extensionworkshop.com/documentation/develop/temporary-installation-in-firefox/)
